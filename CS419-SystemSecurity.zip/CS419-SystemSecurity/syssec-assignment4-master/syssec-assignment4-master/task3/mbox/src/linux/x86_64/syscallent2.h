/* Our third set is for x32.  */
#include "x32/syscallent.h"
