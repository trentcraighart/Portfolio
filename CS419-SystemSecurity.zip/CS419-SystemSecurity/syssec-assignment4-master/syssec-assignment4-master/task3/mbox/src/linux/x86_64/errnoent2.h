/* Our third set is for x32.  */
#include "../errnoent.h"
