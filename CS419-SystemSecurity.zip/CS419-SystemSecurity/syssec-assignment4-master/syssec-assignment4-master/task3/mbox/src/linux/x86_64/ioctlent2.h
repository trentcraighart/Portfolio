/* Our third set is for x32.  */
#include "linux/ioctlent.h"
