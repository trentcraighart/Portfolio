#include <stdio.h>

int main() {
    puts("This program does nothing!\n");
}
