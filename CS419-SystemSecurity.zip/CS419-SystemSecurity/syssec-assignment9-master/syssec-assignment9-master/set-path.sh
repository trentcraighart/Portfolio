#!/bin/sh
ln -s `pwd`/pin*/pin $HOME/bin
