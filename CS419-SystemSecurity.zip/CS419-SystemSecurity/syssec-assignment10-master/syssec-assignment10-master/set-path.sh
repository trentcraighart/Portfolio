#!/bin/bash
export PATH=$PATH:`pwd`/afl-2.52b
export AFL_PATH=`pwd`/afl-2.52b
bash
