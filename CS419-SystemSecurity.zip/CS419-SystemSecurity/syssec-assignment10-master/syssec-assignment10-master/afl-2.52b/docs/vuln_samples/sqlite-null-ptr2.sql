DETACH(select group_concat(q));
