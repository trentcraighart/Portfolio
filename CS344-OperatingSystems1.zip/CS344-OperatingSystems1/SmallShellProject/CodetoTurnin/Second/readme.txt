Trent Vasquez
vasquezt

to compile, use the command
gcc smallsh.c -o smallsh -w

*note the -w is for the invalid type error
