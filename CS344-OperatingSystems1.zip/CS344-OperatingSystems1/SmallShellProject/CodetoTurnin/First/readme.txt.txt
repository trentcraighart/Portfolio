Trent Vasquez: 932-295-132

Compile Command:
gcc smallsh.c -o smallsh

