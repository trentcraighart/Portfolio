// Client side C/C++ program to demonstrate Socket programming
// Scott Merrill & Trent Vasquez
//Network Resource: https://www.geeksforgeeks.org/socket-programming-cc/
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <openssl/sha.h>
#define PORT 40400

void gen_random(char *s, const int len) {
    static const char alphanum[] =
        "0123456789"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz";
    int i;
    for (i = 0; i < len; ++i) {
        s[i] = alphanum[rand() % (sizeof(alphanum) - 1)];
    }

    s[len] = 0;
}

int main(int argc, char const *argv[])
{
    struct sockaddr_in address;
    int sock = 0, valread;
    struct sockaddr_in serv_addr;
    char *hello = "Client: Connection Request";
    char buffer[1024] = {0};
    srand(time(NULL));
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("\n Socket creation error \n");
        return -1;
    }
  
    memset(&serv_addr, '0', sizeof(serv_addr));
  
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
      
    // Convert IPv4 and IPv6 addresses from text to binary form
    if(inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr)<=0) 
    {
        printf("\nInvalid address/ Address not supported \n");
        return -1;
    }
  
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    {
        printf("\nConnection Failed \n");
        return -1;
    }

    /********          Send Connection Request           *********/
    send(sock , hello , strlen(hello) , 0 );
    printf("Connection Request sent\n");

    
    /********          Wait for Puzzle response           *********/
    valread = read( sock , buffer, 1024);
    printf("Response Recieved\n");
    //printf("%s\n",buffer );
    int buflen = strlen(buffer);
    printf("Length of buffer: %i\n",buflen );
    if(buflen == 1){
        printf("\nError: Try again\n");
        return 0;
    }
    /********          Solve Puzzle           *********/
    clock_t start, end;
    char sol[buflen];
    char temp[buflen];
    int j;
    for(j=0;j<buflen;j++)
        sol[j] = '1';
    start = clock();
    // Find hash solution
    printf("Solving...\n\n");
    while(strcmp(buffer, sol) != 0){\
        // generate random string
        gen_random(temp, buflen);

        unsigned char digest[SHA_DIGEST_LENGTH];
        SHA((unsigned char*)&temp, buflen, (unsigned char*)&digest);    
     
        char mdString[SHA_DIGEST_LENGTH*2+1];
        int i;
        for(i = 0; i < SHA_DIGEST_LENGTH; i++)
             sprintf(&mdString[i*2], "%02x", (unsigned int)digest[i]);
        int j;
        for(j=0; j<buflen; j++)
            sol[j] = mdString[j];
        //printf("%s , %s\n",&sol,&buffer );
    }
    end = clock();
    //printf("Recieved: %s, Solution: %s, Hash: %s\n",&buffer,&temp,&sol);
    int final = (long double) (end - start)/1000;
    printf("Time Elapsed: %i ms \n", final);

    /********          Send Solution           *********/
    printf("Solution Sent\n");
    send(sock, sol, buflen,0);

    return 0;
}
