## Capstone_Group_66  
Our software development suite for ED optimization  
**This should be run on windows.** The GUI has issues on Linux, if you must run on linux try runwithoutgui.py  

To run our program first enter the Code7Opt directory
`$ cd Code7Opt`

Next run the dependencies script to ensure all packages are installed

`$ ./dependencies.sh`
or 
`$ bash ./dependencies.sh`

This will install the python packages required to run our program:  
`$python3 main.py`

In the GUI the user can specify the following values:  
*Enter Population Hospital Serves*  
*Enter Number of Beds in Hospital*  
*Enter ED Doctor Count of Hospital*  
*Enter Nurse Count of Hospital*  
The values must be larger than 1  
The population value influences the number of patients that walk in  
For reference, Corvallis has a population of around 60,000  

While the application is performing optimization it can take roughly 3 minutes 
It may not appear to be doing anything, but as long as "Optimization Has Begun!" is displayed and the program does not crash, it is running!

The output is displayed in the form of a 3D pyplot graph that plots the objectives on their respective labeled axis. Note that the patients seen objective is being maximized!  

The program will also output recommendations from the simulator configurations that did the best in each objective into the terminal  

The exception thrown after the GUI closes is a result of the plotting library being used in combination with the GUI. This has no impact on the program, but cannot be avoided in the current configuration.  

To run our main program without the GUI run this after using the dependencies script

`$ python3 runWithoutGui.py`

This script uses hardcoded input values of (citySize=60000, beds=10, docs=15, nurses=15)

