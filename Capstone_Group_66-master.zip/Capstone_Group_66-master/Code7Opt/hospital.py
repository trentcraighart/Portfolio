import random
import simpy
import math
import operator
import numpy as np
import pandas as pd
import yaml
import argparse
from numpy.random import choice
from numpy.random import RandomState

import patient

RANDOM_SEED = 12345
RNG_SEED = 800
prng = RandomState(RNG_SEED)
np.random.seed(RANDOM_SEED)

TOTAL_SHIFTS = 10
SHIFT_TIME = 720
SIM_TIME = TOTAL_SHIFTS * SHIFT_TIME #Goal is 12 hour window
PATIENT_CHANCE = 0.0477495 #Based on rate of ER admissions and Corvallis Population

BED_MATINENCE = 10 * 8 #The price that a bed will cost to maintain over 8 hours
DOCTOR_PAY = 135 * 8 #The price a doctor will cost for 8 hours of pay
NURSE_PAY = 100 * 8 

#GETTING RATES OF PATIENT ESI, RESOURCE CONNSUMPTION, AND TIME IN HOSPITAL
with open("config.yml", 'r') as ymlfile:
	cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)
ESI_CHANCE = cfg['ESI-Chance']
ESI_CONSUME = [cfg['ESI-Consume']['ESI1'], cfg['ESI-Consume']['ESI2'], cfg['ESI-Consume']['ESI3'], 
	cfg['ESI-Consume']['ESI4'], cfg['ESI-Consume']['ESI5'],]
ESI_TIME = [cfg['ESI-Time']['ESI1'], cfg['ESI-Time']['ESI2'], cfg['ESI-Time']['ESI3'], 
	cfg['ESI-Time']['ESI4'], cfg['ESI-Time']['ESI5'],]
INSURANCE = [cfg['INSURANCE']['PRIVATE'], cfg['INSURANCE']['MEDICAID'], cfg['INSURANCE']['MEDICARE'], cfg['INSURANCE']['UNINSURED']]
INSURANCE_PRECENTAGES = [INSURANCE[0][0], INSURANCE[1][0], INSURANCE[2][0], INSURANCE[3][0]]
INSURANCE_PRICE_MOD = [INSURANCE[0][1], INSURANCE[1][1], INSURANCE[2][1], INSURANCE[3][1]]

# Hospital metrics used instead of predictor data:
# http://emergencias.portalsemes.org/descargar/evidence-of-the-validity-of-the-emergency-severity-index-for-triage-in-a-general-hospital-emergency-department/force_download/

#Parse the args for a single instance bed/doctor combonation 
# parser = argparse.ArgumentParser()
# parser.add_argument("-beds", metavar = "-b", type=int)
# parser.add_argument("-doctors", metavar = "-d", type=int)
# parser.add_argument("-margin", metavar = "-p", type=int)
# args = parser.parse_args()




# saves to CSV and reports to terminal
def simulation_report(results, file_output = True):
	df = pd.DataFrame(columns=['num_beds', 'num_doctors', 'attempted_margin', 'actual_margin', 'waiting_patients', 
		'healed_patients', 'average_stay', 'avgerage_payment', 'profit','cost'])
	index = 0
	#print("resulting metrics:")
	for result in results:
		#RESULT 0 is the config object
		num_docs = result[0].num_doctors
		num_beds = result[0].num_beds
		margin  = result[0].margin

		#RESULT 1 is the metric object
		num_waiting = result[1].num_waiting
		num_resting = result[1].num_resting
		num_healed = result[1].num_healed
		avg_stay = result[1].avg_stay

		avgerage_payment = result[1].avgerage_payment
		actual_margin = result[1].actual_margin
		profit= result[1].profit
		cost = result[1].cost

		#print("size of paper trail: " + str(len(result[1].papertrail)))
		df.loc[index] = [num_beds, num_docs, margin, actual_margin, num_waiting, 
			num_healed, avg_stay, avgerage_payment, profit, cost]
		index += 1
	#df = df.sort_values(by=['cost'])
	#df = df.sort_values(by=['average_stay'])
	#print("Printing Simulation Report")
	#print(df)

	#can output to csv if you want
	if file_output:
		df.to_csv("simulator_output.csv", sep=',')
	return df
	
# Defines how hospital is setup
class Config(object):
	def __init__(self, num_doctors, num_beds, margin, num_nurses, num_equipment, sim_time, previous_patients, patientCount):
		self.num_doctors = num_doctors
		self.num_beds = num_beds
		self.num_nurses = num_nurses
		self.num_equipment = num_equipment
		self.sim_time = sim_time
		self.previous_patients = previous_patients
		self.patient_chance = (patientCount) / 1440
		self.margin = margin

# Keeps track of everything simulator will output
class Metrics(object):
	def __init__(self, config, env):
		self.config = config
		self.history = []
		self.papertrail = []
		self.env = env

		self.margin = self.config.margin
		self.num_waiting = 0
		self.num_healed  = 0
		self.num_resting = 0
		self.avg_stay = 0
		self.cost = 0
		self.profit = 0
		self.avgerage_payment = 0

	def update_metrics(self):
		#Patients will only be billed after their visit is over
		self.set_avg_stay()
		self.set_patient_locations()
		self.set_cost_and_profits()


	def set_patient_locations(self):
		healthy = 0
		resting = 0
		waiting = 0
		for patient in self.history:
			if(patient.bed_arrive == 0):
				waiting += 1
			else:
				if(patient.condition == "healthy"):
					healthy += 1
				else:
					resting += 1
		self.num_healed = healthy
		self.num_resting = resting
		self.num_waiting = waiting

	# average stay of patients who went through the whole process
	def set_avg_stay(self):
		stay_total = 0
		healthy_patients = 0
		for patient in self.history:			
			if(patient.condition == "healthy"):
				stay_total += (patient.bed_leave - patient.arrival_time)
				healthy_patients += 1
		if healthy_patients == 0:
			self.avg_stay = 999999
			return 
		self.avg_stay = stay_total/healthy_patients
		

	def set_cost_and_profits(self):
		cost = 0
		# doctors charge by the minute
		cost += self.config.num_doctors * DOCTOR_PAY * TOTAL_SHIFTS 
		# beds are a fixed cost
		cost += self.config.num_beds * BED_MATINENCE * TOTAL_SHIFTS 

		cost += self.config.num_nurses * NURSE_PAY * TOTAL_SHIFTS
		# patient wait times have a cost
		#for patient in self.history:
		#	cost += patient # time is money!
		#cost += self.avg_stay * (self.num_healed)
		#cost += self.avg_stay * (len(self.history) - self.num_healed) * 10
		'''
		REMOVED INSURANCE TYPING AND SELECTION FROM CURRENT EQUATION FOR NOW UNTIL I CAN DO THE MATH PROPERLY
		#Get payments from patients
		payment_modifier = []
		for x in range (0, 4):
			payment_modifier.append(INSURANCE_PRICE_MOD[x] * (self.margin / 0.078))
		'''	
		cur_payments = 1
		for patient in self.history:
			if (patient.bedtime > 0):
				#To get the cost the patient has acrewed, we d do the following function
				patient_cost = BED_MATINENCE * (patient.time_to_heal / SHIFT_TIME) + (DOCTOR_PAY * ((patient.time_to_heal / 4 + 15) / SHIFT_TIME)) # The +15 is for paperwork
				#k = choice([0,1,2,3], 1, p = INSURANCE_PRECENTAGES)
				cur_payments += (patient_cost / (self.margin - 1)) * -1 
				'''
				current_payments = (patient_cost / (self.margin - 1)) * -1
				print("Current Payment = patient cost / (margin - 1) * - 1")
				print(str(current_payments) + " = " + str(patient_cost) + " / ( " + str(self.margin)
					+ " - 1 ) * - 1")
				cur_payments += current_payments
				'''

		self.profit = cur_payments
		self.cost = cost

		gross = cur_payments - cost
		margin = gross / cur_payments
		self.actual_margin = margin
		


	def print_metrics(self):		
		self.update_metrics()

		print("Average stay length:")		
		print(self.avg_stay)

		print("cost:")
		print(self.cost)

		print("Healed Patients:")
		print(self.num_healed)

		print("In beds:")
		print(self.num_resting)

		print("Waiting:")
		print(self.num_waiting)

		print("Profit Margin:")
		print(self.actual_margin)

# Contains and manages resources other processes engage with
class Hospital(object):	
	def __init__(self, env, config, metrics):
		self.doctors =simpy.PreemptiveResource(env, capacity=config.num_doctors) #simpy.PreemptiveResource(env, capacity=config.num_doctors)
		self.beds =simpy.PreemptiveResource(env, capacity=config.num_beds) #simpy.PreemptiveResource(env, capacity=config.num_beds)
		self.nurses =simpy.PreemptiveResource(env, capacity=config.num_nurses)
		self.equipment = simpy.PreemptiveResource(env, capacity=config.num_equipment)
		#self.equipment =simpy.Resource(env, capacity=config.num_equipment)

class Paperwork(object):
	def __init__(self, env, hospital):
		self.env            = env
		self.hospital       = hospital
		self.work_remaining = 10.0
		self.doc_arrive     = 0
		self.doc_leave      = 0
		self.process = self.env.process(self.complete_paperwork())

	def complete_paperwork(self):
		#print("new paperwork!")
		while (self.is_incomplete()):
			try: 
				with self.hospital.doctors.request(priority=-1, preempt=False) as doc_req:
					yield doc_req						
					self.doc_arrive = self.env.now
					yield self.env.timeout(4) | self.env.timeout(self.work_remaining)
					self.work_remaining -= self.env.now - self.doc_arrive
					#print("paperwork has: " + str(self.work_remaining))
			except simpy.Interrupt:
				#print("paperwork unfinished!")
				#print("paperwork finished")
				continue
	def is_incomplete(self):
		return self.work_remaining > 0.1

# generates patient for hospital
# predictor / monte carlo will go somewhere in here
# currently generates when asked, should it output a full list all at once?
class patient_generator(object):
	def __init__(self, env):
		self.env = env
		self.total_patients = 0

	def make_patient(self, hospital):
		pat_esi = self.get_status()
		pat_com = self.get_consume(pat_esi)
		pat_tim = self.get_time(pat_esi)
		new_pat = patient.Patient(self.env, pat_esi, pat_com, pat_tim, self.total_patients, hospital)
		self.total_patients += 1
		return (new_pat)

	# Patient esi status upon enter the hospital
	def get_status(self):	
		return choice([1,2,3,4,5], 1, p = ESI_CHANCE)[0]

	# Amount resources patient consumes during their visit
	def get_consume(self, esi):
		return choice([1,2,3], 1, p = ESI_CONSUME[esi-1])[0]

	# Time patient needs in bed to be discharged
	def get_time(self, esi):
		return (ESI_TIME[esi - 1][0] + ESI_TIME[esi - 1][1] * random.uniform(.5, 1.5))


def setup(env, config, metrics):
	hospital = Hospital(env, config, metrics)
	mafia = patient_generator(env) #JOKE

	# Simulation loop - each iteration is one minute
	while True:			
		if (random.random() < config.patient_chance): #Corvallis has the odds of 0.0477495 each minute of a patient showing up to the emergency department.
			metrics.history.append(mafia.make_patient(hospital))					
			metrics.papertrail.append(Paperwork(env, hospital))
		#if (random.random() < 0.5):
		#	metrics.papertrail.append(Paperwork(env, hospital))
		#if(env.now % 100 == 0):
			#print("\nHOSPITAL CURRENT STATS AT TIME: " + str(env.now))
			#print("waiting / healed counts to be readded")
			#print("PATIENTS WAITING: "  + str(len(hospital.patients)))
			#print("PATIENTS HEALED:  " + str(hospital.discharged) + "\n")
		yield env.timeout(1)
		

def simulate(config):
	#print('New Hospital')
	random.seed(RANDOM_SEED)  

	env = simpy.Environment()
	metrics = Metrics(config, env)
	env.process(setup(env, config, metrics))
	
	#print("\n*")
	#print("Starting  Doctors: " + str(config.num_doctors) + " Beds: " + str(config.num_beds))
	env.run(until=config.sim_time)
	#print("\nFinishing Doctors: " + str(config.num_doctors) + " Beds: " + str(config.num_beds))
	metrics.update_metrics()
	#metrics.print_metrics()
	#print("*\n")
	return metrics


'''
# Sequence of program execution

Record Object is initialized:
	Maintains record of hospitalized paitents and the time to help

Simulate Object:
	Simulate sets up simpy enviroment to equal the setup function
	Also takes in basic inputs for the simulation
	Have the process run until time is "up"

Setup:
	Takes basic inputs from simulate
	Initializes the Hospital 
	Randomly Generate patients for hospital forever
'''


#config = Config() get a config
#run the simulator metrics = simulate(config)
#simulationreport(results)
#return the df to the optimizer

def optimizerCall(num_docs, num_beds, num_nurses, num_equipment, pCountArray):
	results = []
	for pCount in pCountArray:
		config = Config(num_docs, num_beds, .45, num_nurses, num_equipment, SIM_TIME, [], pCount)
		results.append((config,simulate(config)))
		#since this doesn't work yet we dont want to run the same sim 4 times

	# Our total population * CDC chance for a person to go to the ER on a given day / minuets in day
	df = simulation_report(results, False)
	return [df.at[0, 'average_stay'], df.at[0,'cost'], df.at[0,'healed_patients']]#healed_patients
