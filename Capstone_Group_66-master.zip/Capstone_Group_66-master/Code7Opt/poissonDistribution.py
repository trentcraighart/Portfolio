import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


RANDOM_SEED_DIST = 12345



def createPoissonDistribution(pRate, population, sampleSize):
    np.random.seed(RANDOM_SEED_DIST)
    distribution = population * pRate
    pDist = np.random.poisson(distribution, sampleSize)
    # createPlot(pDist, sampleSize)
    return pDist


def selectSamplesFromDistribution(poissonDist):
    mean = np.mean(poissonDist)
    stdDev = np.std(poissonDist)
    s1 = int(mean+stdDev) 
    #s2 = int(mean-stdDev)
    s3 = int(s1 * 1.5) #monte carlo :^)
    s4 = int(mean)
    samples = [s1, s3, s4]
    return samples

def savePoissonToCSV(pDist):
    pd.DataFrame(pDist).to_csv("poisson.csv", header=None, index=None, float_format="%d")



def createPlot(poisson, sampleSize):
    plt.hist(poisson, bins = 15)
    # plt.axis([6500, 7200, 0, 150])
    plt.grid(True)
    plt.title("Frequency of Paitents Per Eight Hour Period of Day")
    plt.xlabel("Patient Count")
    plt.ylabel("Frequency (out of " + str(sampleSize) + " samples)")
    plt.show()
    # plt.savefig("poissonDistribution_" + str(period) + ".png")
    return plt


#pd.DataFrame(output).to_csv("poisson.csv", header=None, index=None, float_format="%d")

# dist = createPoissonDistribution(.04, 10000, 5)
# dist2 = createPoissonDistribution(.04, 10000, 1000)

# createPlot(dist, 5)
# createPlot(dist2, 1000)