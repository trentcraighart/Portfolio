#!/bin/bash

function pip_install {
    for p in $@; do
        pip install $p
        if [ $? -ne 0]; then
            echo "Couldn't install $p - abort"
            exit 1
        fi
    done
}


pip_install pandas 
pip_install argparse 
pip_install progressbar2 
pip_install simpy 
pip_install pyyaml  
pip_install pyqt5 
pip_install platypus-opt
pip_install matplotlib
