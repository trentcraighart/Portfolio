import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import csv


def showResults(result):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.scatter([s.objectives[0] for s in result],
            [s.objectives[1] for s in result],
            [s.objectives[2] for s in result])
    ax.set_xlabel('avg stay')
    ax.set_ylabel('cost')
    ax.set_zlabel('patients seen')
    plt.show()

def showResultsFromFile(fileName):
    with open(fileName, newline='') as csvfile:
        creader = csv.reader(csvfile, csv.QUOTE_NONNUMERIC)
        x = []
        y = []
        z = []
        for row in creader:
            x.append(float(row[0]))
            y.append(float(row[1]))
            z.append(float(row[2]))
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.scatter(x, y, z)
        ax.set_xlabel('avg stay')
        ax.set_ylabel('cost')
        ax.set_zlabel('patients seen')
        plt.show()
