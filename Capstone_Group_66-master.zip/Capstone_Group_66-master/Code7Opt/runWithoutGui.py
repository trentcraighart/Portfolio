import optimizerFramework as optimizer


if __name__ == "__main__":
    optimizer.optimize(60000, 10, 15, 15, False)

