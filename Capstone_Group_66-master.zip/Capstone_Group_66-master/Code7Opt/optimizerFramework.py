from platypus import *
import hospital as simulator
import poissonDistribution as dataGenerator
import displayResults as displayResults
import csv
import datetime


class SimConfig():
    def __init__(self,numdocs, numnurses, numbeds, numequip):
        self.docs = numdocs
        self.beds = numbeds
        self.nurses = numnurses
        self.equip = numequip

    def printConfig(self):
        prntStr = "Docs: {} Nurses: {} Beds: {}".format(self.docs, self.nurses, self.beds)
        print(prntStr)


class Code7Optimizer(Problem):

    #takes in input variables types (range of values) ex: Integer(0, 20)
    def __init__(self, docTypes, nurseTypes, bedTypes, pCountArray):
        NUMOBJS = 3
        super(Code7Optimizer, self).__init__(3, NUMOBJS, 0)# define 3 inputs and 3 objective 
        self.types[:] = [docTypes, nurseTypes, bedTypes] # list of problem constraints
        self.directions[2] = Problem.MAXIMIZE
        self.pCountArray = pCountArray
        self.bestObjs = []
        for i in range(NUMOBJS):
            if (self.directions[i] == Problem.MAXIMIZE):
                self.bestObjs.append((0, None))
            else:
                self.bestObjs.append((9999999, None))
        
        #probably should import and setup the simulator with data here

    #objective function
    #this needs to: take the input variables (docs, nurses, beds)
    #add them to the simulator config
    #run the simulator
    #pull the metrics after simulator is complete
    #compute and return objectives

    #Input variables(docs, nurses, beds): solution.variables[]
    #Objectives(avg stay, cost, patients seen): solution.objectives[]
    def evaluate(self, solution):
        inVars = solution.variables[:]
        cfg = SimConfig(inVars[0], inVars[1], inVars[2], 10)
 

        #UPDATE SIM CONFIG (YAML OR CMD LINE?)
        #run sim
        objs = simulator.optimizerCall(cfg.docs, cfg.beds, cfg.nurses, 10, self.pCountArray)

        #get output and process objectives
        #1 is averagee stay
        #2 is cost
        #3 patients seen
        i = 0
        for obj in objs:
            if (self.directions[i] == Problem.MAXIMIZE):
                if obj > self.bestObjs[i][0]:
                    self.bestObjs[i] = (obj, cfg)
            else:
                if obj < self.bestObjs[i][0]:
                    self.bestObjs[i] = (obj, cfg)
            i +=1


        solution.objectives[:] = objs #return array of 3 objectives




def optimize(cityPopulation, bedCount, doctorCount, nurseCount, writeToFile=False):
    # problem = [DTLZ2] # example problem 

    #algs = [NSGAII, (NSGAIII,{"divisions_outer":2}), SPEA2]

    numDoctors = Integer(1, doctorCount) # decision variable ranges
    numNurses = Integer(1, nurseCount)
    numBeds = Integer(1, bedCount)
    dist = dataGenerator.createPoissonDistribution(0.0011863, cityPopulation, 500)
    pCountArray = dataGenerator.selectSamplesFromDistribution(dist)
    problem = Code7Optimizer(numDoctors, numNurses, numBeds, pCountArray)

    #results = experiment(algs, problem, seeds=3, nfe=5000)
    #print(results)
    # dist = dataGenerator.createPoissonDistribution(.05, 10000, 1000)
    #print(dist)
   # hyp = Hypervolume(minimum=[0, 0, 0], maximum=[1, 1, 1])
   # hyp_result = calculate(results, hyp)
   # display(hyp_result, ndigits=3)
    algorithm = NSGAII(problem)

# optimize the problem using 10,000 function evaluations
    #algorithm.run(4)#probably less
    algorithm.run(4)


    i = 0
    objNames = ["Avg Patient Stay: ", "Cost: ", "Patients Seen: "]
    print("-----Recommendations------")
    for tup in problem.bestObjs:
        print("Objective", objNames[i], end='')
        if tup[1] is not None:
            tup[1].printConfig()
        i+=1
    print("--------------------------")


    if writeToFile:
        dt = datetime.datetime
        dateStr = dt.today().strftime("run_%m.%d-%H.%M.%S")
        with open(dateStr, 'w',newline='') as csvfile:
            writer = csv.writer(csvfile)
            for sol in algorithm.result:
                writer.writerow(sol.objectives)
    else:
        displayResults.showResults(algorithm.result)

    # calculate hypervolume indicator
    # hyp = Hypervolume(minimum=[0,0,0], maximum=[1,1,1])
    # hyp_result = calculate(algorithm.result, hyp)
    # display(hyp_result, ndigits=3)
    #print(algorithm.result)






    # plt.scatter([s.objectives[0] for s in algorithm.result],
    #         [s.objectives[1] for s in algorithm.result])
    # plt.xlabel("$f_1(x)$")
    # plt.ylabel("$f_2(x)$")
    # plt.show()

