import simpy

class Patient(object):
	def __init__(self, env, status, consume, time_to_heal, id, hospital):
		self.env           = env
		self.hospital      = hospital
		self.status        = status
		self.consume       = consume
		self.time_to_heal  = time_to_heal
		self.bedtime_need  = time_to_heal
		self.doctime_need  = time_to_heal/4 #Using the source http://ugeskriftet.dk/files/scientific_article_files/2018-12/a4558.pdf
		self.bedtime       = 0 		
		self.doctime       = 0 
		self.arrival_time  = env.now
		self.doc_arrive    = 0
		self.doc_leave     = 0 
		self.bed_arrive    = 0		
		self.bed_leave     = 0 
		self.has_bed       = False
		self.has_doc       = False		
		
		self.id = id
		self.condition     = "sick"
		self.departure_time= 0                
		self.process = self.env.process(self.emergency_visit())

	# patient will stay in bed unless pre-empted to exit it
	# patient will then repeatedly request doctor until they don't need them

	# most important function
	# controls what patient does, how long they delay between each stage
	# also deals with patient priorities
	# MUST be structured with yields this way for simpy to operate properly. 
	# 	yields inside of member functions will give bizzare results
	def emergency_visit(self):
		self.arrive()
		admitted = False
		while (admitted == False):
			try: 
				with self.hospital.nurses.request(priority=self.status, preempt=True) as nurse_req:			
					yield nurse_req
					with self.hospital.equipment.request(priority=self.status, preempt=True) as equip_req:
						yield equip_req
						yield self.env.timeout(10)
						admitted = True
			except simpy.Interrupt:
				#print("interrupted_admission")
				self.print_message("interrupted!")		
		while self.is_not_healthy():			
			try:
				with self.hospital.beds.request(priority=self.status, preempt=True) as bed_req:			
					yield bed_req
					self.get_in_bed()						
					while (self.is_doc_needed()):
						with self.hospital.doctors.request(priority=self.status, preempt=True) as doc_req:
							yield doc_req						
							with self.hospital.equipment.request(priority=self.status, preempt=True) as equip_req:
								yield equip_req
								yield self.env.timeout(4) | self.env.timeout(self.feed_and_water("start"))
								self.feed_and_water("end")
					yield self.env.timeout(self.rest("start"))
					self.rest("end")
					
			except simpy.Interrupt:
				self.print_message("interrupted!")
				self.feed_and_water("end")
				self.rest("end")
		
				
		# healthy!
		self.discharge()

	# patient had some event
	def print_message(self, message):		
		i = 0 #dummy operation to prevent console from being spammed while print is commented
		#print("patient " + str(self.id) + " " + message)

	# put patient in bed and record time
	def rest(self, stage):
		if stage == "start":
			self.print_message("resting")
			self.has_bed = True
			return self.get_bed_need()

		# may be interrupted, if so will need to set bed_leave and bedtime in interrupt handler
		if stage == "end":
			self.bed_leave = self.env.now
			bed_rest = self.bed_leave - self.bed_arrive
			if (self.has_bed):
				self.bedtime += bed_rest
			self.bed_arrive = self.bed_leave			
			self.has_bed = False

	# remaining minutes with doctor to heal
	def get_doc_need(self):
		need = self.doctime_need - self.doctime
		return need

	# remaining minutes in bed to heal
	def get_bed_need(self):
		need = self.bedtime_need - self.bedtime
		return need
		

	# these tell us if patient needs a bed or doctor	
	def is_doc_needed(self):
		return (self.get_doc_need() > 0.1) # 0.1 to avoid floating point madness
	def is_bed_needed(self):
		return (self.get_bed_need() > 0.1)

	# doctor engages patient, record times
	def feed_and_water(self, stage):
		now = self.env.now
		# doctor arrives
		if stage == "start":
			self.print_message("engaging doctor")	
			self.doc_arrive = now
			self.has_doc = True
			return self.get_doc_need()
			
		# doctor leaves
		# if we're interrupted we need to set self.doc_leave & update doctime
		if stage == "end":
			self.doc_leave = now
			if (self.has_doc):
				self.doctime += self.doc_leave - self.doc_arrive
			self.doc_arrive = self.doc_leave
			self.has_doc = False
		

	# records time patient got in bed
	def get_in_bed(self):
		self.print_message("got in bed")
		self.bed_arrive = self.env.now
		self.has_bed = True

	# records when patient arrives
	def arrive(self):	
		# todo: add arrival time here?
		self.print_message("arrived")	

	# patient is healthy, record time & update health
	def discharge(self):
		self.print_message("discharged")	
		self.condition = "healthy"
		self.departure_time= self.env.now

	# how long were they 
	def get_stay_length(self):
		return self.departure_time - self.arrival_time
		#return self.env.now - self.arrival_time

	# do they need our services?
	def is_not_healthy(self):
		return self.is_doc_needed() and self.is_bed_needed()
		