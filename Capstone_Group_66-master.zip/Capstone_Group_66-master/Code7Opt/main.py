import optimizerFramework as optimizer
import sys
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow, QLabel, QFileDialog
from PyQt5 import QtCore, QtGui, QtWidgets, uic
from PyQt5.QtCore import QThread, pyqtSignal, QObject
from UIPage import Ui_MainWindow # importing .ui generated file
 
qtCreatorFile = "UIPage.ui" # Enter file here.
 
class optimizationThread(QThread):
    def __init__(self, cityPopulation, bedCount, doctorCount, nurseCount, trig):
        super(optimizationThread, self).__init__()
        self.cityPopulation = cityPopulation
        self.bedCount = bedCount
        self.doctorCount = doctorCount
        self.nurseCount = nurseCount
        self.trig = trig
    def __del__(self):
        self.wait()
    def run(self):
        optimizer.optimize(self.cityPopulation, self.bedCount, self.doctorCount, self.nurseCount)
        self.trig.emit()

class MyApp(QtWidgets.QMainWindow, QObject):

    finishedRunning = pyqtSignal()
    def __init__(self):
        super(MyApp, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle("Optimizer")
        self.ui.lineEdit_CP.setPlaceholderText("Enter Population Hospital Serves (1>)") 
        self.ui.lineEdit_BC.setPlaceholderText("Enter Number of Beds in Hospital (1>)") 
        self.ui.lineEdit_DC.setPlaceholderText("Enter ED Doctor Count of Hospital (1>)") 
        self.ui.lineEdit_NC.setPlaceholderText("Enter Nurse Count of Hospital (1>)")
        self.ui.resultsWindow.setDisabled(True)
        self.ui.startOptimizationButton.clicked.connect(self.startOptimization)
        self.finishedRunning.connect(self.handleFinishedRunning)

    def startOptimization(self):
        try:
            cityPopulation = int(self.ui.lineEdit_CP.text())
            bedCount = int(self.ui.lineEdit_BC.text())
            doctorCount = int(self.ui.lineEdit_DC.text())
            nurseCount = int(self.ui.lineEdit_NC.text())
        except Exception as e:
            self.ui.resultsWindow.setText("Ensure all inputs are Ints")
            return
        if bedCount <= 1 or doctorCount <= 1 or nurseCount <= 1 or cityPopulation <=1:
            self.ui.resultsWindow.setText("Ensure all inputs > 1")
        else:
            self.ui.resultsWindow.setText("Optimization has begun!")
            try:
                self.myThread = optimizationThread(cityPopulation, bedCount, doctorCount, nurseCount, self.finishedRunning)
                self.myThread.start()
            except Exception as e:
                print(e)
                print ("Error: unable to start optimizer thread")
            self.ui.resultsWindow.setDisabled(True)

    def handleFinishedRunning(self):
        self.close()



if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = MyApp()
    window.resize(1000, 800)
    window.show()
    sys.exit(app.exec_())


