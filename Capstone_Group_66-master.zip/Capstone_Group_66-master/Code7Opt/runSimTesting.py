import hospital
num_docs = 10
num_beds = 10
num_nurses = 5
print(hospital.optimizerCall(num_docs, num_beds, num_nurses, 10))